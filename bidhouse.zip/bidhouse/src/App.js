import React from 'react'
import Navbar from './components/Navbar'
import Home from './components/Home'
import Login from './components/Login'
import Contact from './components/Contact'
import Seller from './components/Seller'
import Signup from './components/Signup'
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';



function App() {
  return (
    <Router>
      <Navbar />
      <Switch>
        <Route path='/' exact component = {Home} />
        <Route path='/seller login' exact component = {Seller} />
        <Route path='/Contact' component={Contact} />
        <Route path='/login' component={Login} />
        <Route path='/Signup' component={Signup} />
        
      </Switch>
    </Router>
  );
}

export default App;
