export const MenuItems = [
    {
      title: 'Seller login',
      path: '/Seller login',
      cName: 'dropdown-link'
    },
    {
      title: 'Guideline',
      path: '/Guideline',
      cName: 'dropdown-link'
    }
  ];