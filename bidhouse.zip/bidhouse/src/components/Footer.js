import React, { Component } from 'react'
import './footer.css'

export class Footer extends Component {
    render() {
        return (
            <div className="footer">
                <ul className="contacts">
                <h1>Contact Us</h1>
                <li>BidHouse_0011@gmail.com</li>
                <li>
                    <a>www.facebook.com/BidHouse_0011</a>
                </li>
                <li>
                    <a>www.instagram.com/BidHouse_0011</a>
                </li>
                <li>
                    <a>www.twitter.com/BidHouse_0011</a>
                </li>
                </ul>
                <ul className="information">
                <h1>Information</h1>
                <li>
                    <a>about Us</a>
                </li>
                <li>
                    <a>Contact info</a>
                </li>
                <li>
                    <a>Google</a>
                </li>
                <li>
                    <a>Our Services</a>
                </li>
                </ul>
                <ul className="follow_Us">
                <h1>Follow Us</h1>
                <li>
                    <a>Facebook</a>
                </li>
                <li>
                    <a>Twitter</a>
                </li>
                <li>
                    <a>Instagram</a>
                </li>
                <li>
                    <a>Messanger</a>
                </li>
                </ul>
            </div>
        )
    }
}

export default Footer
