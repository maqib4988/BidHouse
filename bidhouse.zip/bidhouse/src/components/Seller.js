import React, { Component } from 'react'

export class Seller extends Component {
    render() {
        return (
            <div>
            <form>
            <h1>Signup</h1>
            <div className="container">
            <label for="fname">First Name</label>
            <input
                type="text"
                name="fname"
                placeholder="Enter firstname"
                required
            />

            <label for="lname">Lastname</label>
            <input
                type="text"
                name="lname"
                placeholder="Enter lastname"
                required
            />

            <label for="email">Email address</label>
            <input
                type="text"
                name="email"
                placeholder="Enter email address or Phone Number"
                required
            />

            <label for="CNIC no:">CNIC Number</label>
            <input
                type="number"
                name="CNiC"
                placeholder="34502-3394785-5"
                required
            />

            <label for="uname">User Name</label>
            <input
                type="text"
                name="uname"
                placeholder="Enter username"
                required
            />

            <label for="password">Enter Password</label>
            <input
                type="password"
                name="password"
                placeholder="Enter Passwod"
                required
            />

            <label for="C-password">Confirm Password</label>
            <input
                type="password"
                name="password"
                placeholder="Confirm Passwod"
                required
            />

            <button type="submit" className = 'btn'>Signup</button>
            </div>
        </form>
            </div>
        )
    }
}

export default Seller

