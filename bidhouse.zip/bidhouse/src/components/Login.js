import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import back from './images/background.jpg'
import './Login.css'

export class Login extends Component {
    render() {
        return (
            <div>
                <div className="background">
                    {/* <img className="back" src={back} alt='background'></img> */}
                
                <div className = "form1">
                <h1>Sign In </h1>
                <input type = "text" placeholder = "Enter email or Contact No" name = "email" required/>
                <input type = "password" placeholder = "Enter Password" name = "password" required/>
                <Link to = './Signup'><a>Create New Account</a></Link>
                <Link to = "./">
                <button className = 'btn'> Sign In </button>
                </Link>
                
                </div>
                </div>
            </div>
        )
    }
}

export default Login
