import React, { Component } from 'react'
import img1 from './images/img1.jpg'
import data from './Data'
import './Home.css'
import Footer from './Footer'



export class Home extends Component {
    render() {
        return (
            <div>
                <div className="head">
                <div className="logo">
                    {/* <img className="pic" src="image" alt="logo img"></img> */}
                </div>
                <div className="search">
                <h3>Get Whatever you Want..</h3>
                    <input type="text" className="searchTerm" placeholder="What are you looking for?" required/>
                    <button type="submit" className="searchButton">
                    <i className="fa fa-search"></i>
                </button>
                </div>
                </div>
                <div class="sidenav">
                    <a href="#Categories" className="active">Categories</a>
                    <a href="#about">Electronics Accesories</a>
                    <a href="#services">jewellery & watches</a>
                    <a href="#clients">Bags & shoes</a>
                    <a href="#contact">Outdoor Fun & Sports</a>
                    <a href="#contact">Automotive & Motorbikes</a>
                    <a href="#contact">Antiques & Collectibles</a>
                    <a href="#contact">Home Appliances</a>
                    <a href="#contact">Toy Kids & Babies</a>
                    <a href="#contact">Mobile phones & Tablets</a>
                </div>
                <div className="container">
                    <img className="img" src={img1} alt="tag img"></img>
                    <div className="box">
                    {/* <div className="box1">
                        <h1>Electronics</h1>
                        <p>explore and bid on your desireproducts</p>
                        </div> */}
                    
                    <div className="box1">
                        <h1>Watches</h1>
                        <p>explore your desire antique watches</p>
                        </div>
                        <div className="box1">
                            <h1>Home Appliances</h1>
                            <p>Bid on your desire home appliances</p>
                        </div>
                        </div>
                        <div className="body">
                        <h1>Electronics</h1>
                        </div>
                        <div className="data_div">
                        {/* <img className = "data_div" src = {dat}></img> */}
                        {data.map((data, key) => {
                            return (
                            <div className="inner_div" key={key}>
                                <img src={data.image}></img> 
                                <h1>{data.name}</h1>
                                <p>{data.price}</p>
                            </div>
                            );
                        })}
                        </div>
                        <div className="body">
                        <h1 >Watches</h1>
                        </div>
                        <div className="data_div">
                        
                        {/* <img className = "data_div" src = {require('../images/img1.jpg')}></img> */}
                        {data.map((data, key) => {
                            return (
                            <div className="inner_div" key={key}>
                                <img src={data.image}></img>
                                <h1>{data.name}</h1>
                                <p>{data.price}</p>
                            </div>
                            );
                        })}
                        </div>

                        <div className="body">
                        <h1>Home Appliances</h1>
                        </div>
                        <div className="data_div">
                        {/* <img className = "data_div" src = {require('../images/img1.jpg')}></img> */}
                        {data.map((data, key) => {
                            return (
                            <div className="inner_div" key={key}>
                                <img src={data.image}></img>
                                <h1>{data.name}</h1>
                                <p>{data.price}</p>
                            </div>
                            );
                        })}
                        </div>
                        <Footer/>
                    </div>
                   
            </div>
        )
    }
}



export default Home
