import img from './images/watch.jpg'
export const data = [
    {
        name:"Rechargebale drill",
        price:"3000 min Bid",
        image: {img}  
    },
    {
        name:"watch",
        price:"5000 min Bid",
        image:{img}
    },
    {
        name:"herry poter cycle",
        price:"12000 min Bid",
        image:{img}
    }
]

export default data