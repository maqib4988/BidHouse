import React, { Component } from 'react'
import './Signup.css'
import axios from 'axios'
import {Link} from 'react-router-dom'

export class Signup extends Component {
  constructor(props) {
    super(props)
    this.onChangeFname = this.onChangeFname.bind(this)
    this.onChangeLname = this.onChangeLname.bind(this)
    this.onChangeEmail = this.onChangeEmail.bind(this)
    this.onChangePassword = this.onChangePassword.bind(this)
    this.onChangeUsername = this.onChangeUsername.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  
    this.state = {
       first_name:'',
       last_name: '',
       email: '',
       user_name: '',
       password: ''
    }
  }

  onChangeFname(e){
    this.setState({
      first_name: e.target.value
    })
    console.log("fn")
  }

  onChangeLname(e){
    this.setState({
      last_name: e.target.value
    })
    console.log("ln")
  }

  onChangeEmail(e){
    this.setState({
      email: e.target.value
    })
    console.log("em")
  }

  onChangeUsername(e){
    this.setState({
      user_name: e.target.value
    })
    console.log("un")
  }

  onChangePassword(e){
    this.setState({
      password: e.target.value
    })
    console.log("pp")
  }

  onSubmit(e){
    e.preventDefault();

    const user = {
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      email: this.state.email,
      user_name: this.state.user_name,
      password: this.state.password
    }

    axios
    .post('http://localhost:5000/user',user)
    .then((res) => console.log(res.data))
  }


  
    render() {
        return (
            <div>
                <form>
        <h1>Signup</h1>
        <div className="container">
          <label for="fname">First Name</label>
          <input
            type="text"
            name="fname"
            placeholder="Enter firstname"
            onChange = {this.onChangeFname}
            required
          />

          <label for="lname">Lastname</label>
          <input
            type="text"
            name="lname"
            placeholder="Enter lastname"
            onChange = {this.onChangeLname}
            required
          />

          <label for="email">Email address</label>
          <input
            type="text"
            name="email"
            placeholder="Enter email address or Phone Number"
            onChange = {this.onChangeEmail}
            required
          />

          <label for="uname">User Name</label>
          <input
            type="text"
            name="uname"
            placeholder="Enter username"
            onChange = {this.onChangeUsername}
            required
          />

          <label for="password">Enter Password</label>
          <input
            type="password"
            name="password"
            placeholder="Enter Passwod"
            onChange = {this.onChangePassword}
            required
          />

          {/* <label for="C-password">Confirm Password</label>
          <input
            type="password"
            name="password"
            placeholder="Confirm Passwod"
            required
          /> */}
          <Link to = './login'><button onClick = {this.onSubmit}>Signup</button> </Link>
         
          
        </div>
      </form>
            </div>
        )
    }
}

export default Signup
