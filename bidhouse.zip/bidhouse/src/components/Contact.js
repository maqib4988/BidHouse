import React, { Component } from 'react'
import './contact.css'
import img2 from './images/contact.jpg'

export class Contact extends Component {
    render() {
        return (
            <div class="contact">
                <div className="lines">
                    <h2>Contact Us</h2>
                    <p>let us know about you issues, We'd love to help you:</p>
                </div>
                <div class="row">
                    <div className="column">
                    <img className="img2" src={img2} alt="image" ></img>
                    </div>
                    <div class="column">
                    <form action="/action_page.php">
                        <label for="fname">First Name</label>
                        <input type="text" id="fname" name="firstname" placeholder="Your name.."/>
                        <label for="lname">Last Name</label>
                        <input type="text" id="lname" name="lastname" placeholder="Your last name.."/>
                        <label for="city">City</label>
                        <select id="city" name="city">
                        <option value="Islamabad">Islamabad</option>
                        <option value="Karachi">Karachi</option>
                        <option value="Lahore">Lahore</option>
                        <option value="Peshawar">Peshawar</option>
                        <option value="Quetta">Quetta</option>
                        </select>
                        <label for="subject">Subject</label>
                        <textarea id="subject" name="subject" placeholder="Write something.."></textarea>
                        <input type="submit" value="Submit"/>
                    </form>
                    </div>
                </div>
            </div>

            
        )
    }
}

export default Contact