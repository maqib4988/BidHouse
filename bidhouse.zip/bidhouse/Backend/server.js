const express = require('express')
const dotenv = require('dotenv')
const routes = require('./routes/routes')
const connectDB = require('./config/db')


//load env variables
dotenv.config({path: './config/config.env'})
connectDB()

const app = express()

app.use(express.json())

app.use('/user',routes)

const PORT = process.env.PORT || 5000

app.listen(
    PORT,
    console.log(`server is running on port ${PORT}`)
)