const Users = require('../models/models')
let user = require('../models/models')

exports.getUsers = (req,res,next) =>{
    res.status(200).json({success: true, msg: 'show all users'})
}

exports.postUsers = async (req,res,next) =>{
    const first_name = req.body.first_name;
    const last_name = req.body.last_name;
    const email = req.body.email;
    const user_name = req.body.user_name;
    const password = req.body.password;

    const users = new user({
        first_name,
        last_name,
        email,
        user_name,
        password,
    })

    users.save()
    .then(()=> res.json('Exercise Added!'))
    .catch((err) => res.status(400).json('Error' + err))

    
}

exports.updateUsers = (req,res,next) =>{
    res.status(200).json({success: true, msg: 'show all users'})
}

exports.deleteUsers = (req,res,next) =>{
    res.status(200).json({success: true, msg: 'show all users'})
}