const mongoose = require('mongoose')
const { model } = require('../models/models')

const connectDB = () =>{
    mongoose.connect(process.env.MONGO_URI,{
        useNewUrlParser: true,
        useCreateIndex: true,
        useFindAndModify: false,
        useUnifiedTopology: true,
    })

    const connection = mongoose.connection
    connection.once('open',()=>{
        console.log('mongoDB connection is established')
    })
}

module.exports = connectDB