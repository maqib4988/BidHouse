const express = require('express')
const { Router } = require('react-router-dom')

const {getUsers,postUsers,updateUsers,deleteUsers} = require('../controllers/controllers')

const router = express.Router();

router.route('/')
.get(getUsers)
.post(postUsers)
.put(updateUsers)
.delete(deleteUsers);

module.exports = router